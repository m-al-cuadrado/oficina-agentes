"""Interfaz de Telegram: avisos con botones y comandos básicos.
Solo responde al chat autorizado (ALLOWED_CHAT_ID); al resto lo ignora en silencio."""
import asyncio
import logging

import psycopg
from psycopg.types.json import Jsonb
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, filters)

from config import ALLOWED_CHAT_ID, DATABASE_URL

log = logging.getLogger(__name__)
ONLY_ME = filters.Chat(chat_id=ALLOWED_CHAT_ID)
ICONS = {"urgente": "🔴", "cliente": "🟠", "factura": "🧾", "otro": "📩"}


def _cut(text, n):
    """Una sola línea y longitud limitada. El texto del correo no es de fiar."""
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[: n - 1] + "…"


# ---------- base de datos (síncrono; se llama con asyncio.to_thread) ----------
def mark_notified(mail_id):
    with psycopg.connect(DATABASE_URL) as c:
        c.execute("UPDATE emails SET status='notified', updated_at=now() "
                  "WHERE id=%s AND status='classified'", (mail_id,))


def _set_status(mail_id, status):
    with psycopg.connect(DATABASE_URL) as c:
        c.execute("UPDATE emails SET status=%s, updated_at=now() WHERE id=%s",
                  (status, mail_id))


def _log_event(event, detail):
    with psycopg.connect(DATABASE_URL) as c:
        c.execute("INSERT INTO agent_log(agent, event, detail) VALUES ('telegram', %s, %s)",
                  (event, Jsonb(detail)))


def _pending():
    with psycopg.connect(DATABASE_URL) as c:
        return c.execute(
            "SELECT category, subject, summary FROM emails "
            "WHERE status='classified' AND (category IN ('urgente','cliente') OR needs_reply) "
            "ORDER BY created_at DESC LIMIT 10").fetchall()


# ---------- avisos ----------
async def send_mail_alert(bot, mail, res):
    text = (
        f"{ICONS.get(res['category'], '📩')} {res['category'].upper()}"
        f"{' · requiere respuesta' if res.get('needs_reply') else ''}\n"
        f"De: {_cut(mail['sender'], 100)}\n"
        f"Asunto: {_cut(mail['subject'], 150)}\n\n"
        f"{_cut(res['summary'], 400)}"
    )
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("✍️ Redactar borrador", callback_data=f"draft:{mail['id']}"),
        InlineKeyboardButton("🙈 Ignorar", callback_data=f"ignore:{mail['id']}"),
    ]])
    # Sin parse_mode: texto plano, para que el contenido del correo no pueda inyectar formato.
    await bot.send_message(chat_id=ALLOWED_CHAT_ID, text=text, reply_markup=keyboard)


# ---------- comandos ----------
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Oficina activa ✅\n/pendientes — correos importantes sin gestionar")


async def cmd_pendientes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = await asyncio.to_thread(_pending)
    if not rows:
        await update.message.reply_text("No hay correos importantes pendientes ✅")
        return
    lines = [f"{ICONS.get(cat, '📩')} {_cut(subj, 80)} — {_cut(summ, 120)}"
             for cat, subj, summ in rows]
    await update.message.reply_text("Pendientes:\n\n" + "\n\n".join(lines))


# ---------- botones ----------
async def on_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if update.effective_chat is None or update.effective_chat.id != ALLOWED_CHAT_ID:
        return
    action, _, mail_id = (q.data or "").partition(":")

    if action == "ignore":
        await q.answer()
        await asyncio.to_thread(_set_status, mail_id, "ignored")
        await asyncio.to_thread(_log_event, "mail_ignored", {"mail_id": mail_id})
        await q.edit_message_text(f"{q.message.text}\n\n✔ Ignorado")
    elif action == "draft":
        # Día 4: solo registramos la petición. El redactor real llega en el Día 5.
        await asyncio.to_thread(_log_event, "draft_requested", {"mail_id": mail_id})
        await q.answer("Petición registrada. El redactor se conecta en el Día 5.", show_alert=True)
    else:
        await q.answer()


def register(app: Application):
    app.add_handler(CommandHandler("start", cmd_start, filters=ONLY_ME))
    app.add_handler(CommandHandler("pendientes", cmd_pendientes, filters=ONLY_ME))
    app.add_handler(CallbackQueryHandler(on_button))
